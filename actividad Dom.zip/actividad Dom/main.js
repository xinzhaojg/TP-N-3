//crear una variable que identifique a mi div de ID "contenedor"
let contenedor = document.getElementById("contenedor")

//creamos una etiqueta desde 35 de tipo "h1"
let titulo = document.createElement("h1")

//le damos un contenido o texto
titulo.textContent = "Actividad 1- DOM"
titulo.style.color="green"

//.appenChild permite agregar el titulo dentro del contenedor
contenedor.appendChild(titulo)

let subtitulo = document.createElement("h2")
subtitulo.textContent = "Programacion I :D"
subtitulo.style.color="red"
contenedor.appendChild(subtitulo)

let tabla= document.createElement("tabla")//tabla
let header = document.createElement("thead")//encabeza
let filaEncabezado = document.createElement("tr")//fila encabezado
let th1 = document.createElement("th")//columna
th1.textContent="Titulo"
th1.style.color="gray"

let th2= document.createElement("th")//columna 2
th2.textContent="Año"
th2.style.color="purple"

filaEncabezado.appendChild(th1)//agregamos columna 1
filaEncabezado.appendChild(th2)//agregamos columna 2
header.appendChild(filaEncabezado)
tabla.appendChild(header)

let body= document.createElement("tbody")
let filaBody1= document.createElement("tr")
let td1=document.createElement("td")//columna vody >td
td1.textContent="Harry Potter"
td1.style.color="brown"

let td2= document.createElement("td")
td2.style.color= "blue"
td2.textContent= "2001"

filaBody1.appendChild(td1)
filaBody1.appendChild(td2)
body.appendChild(filaBody1)


//2do fila del cuerpo de la tabla
let filaBody2= document.createElement("tr")

let td3=document.createElement("td")
td3.textContent="Robots"
td3.style.color="orange"

let td4=document.createElement("td")
td4.textContent="2005"
td4.style.color="cyan"

filaBody2.appendChild(td3)
filaBody2.appendChild(td4)
body.appendChild(filaBody2)

tabla.appendChild(body)

contenedor.appendChild(tabla)